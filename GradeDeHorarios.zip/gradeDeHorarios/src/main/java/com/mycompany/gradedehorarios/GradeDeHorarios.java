/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.gradedehorarios;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Nathan Michel Silva de Oliveira
 */
public class GradeDeHorarios {
    //criação da grade
    private static final String[][] grade = new String[5][7];
    
    //Main Class
    public static void main(String[] args) {
        
        displayGrade();
        System.out.println("\n");
        
        int escolha;
        Scanner scanner = new Scanner(System.in);
        //Loop infinito para fazer o menu
        while(true) {
            //Menu
            System.out.println("1 - Adicionar evento na grade");
            System.out.println("2 for Sair");
            escolha = scanner.nextInt();

            switch(escolha){
                case 1 -> {
                    adicionarNaGrade();
                    System.out.println("\n");
                }
                case 2 -> {
                    System.out.println("Saindo...");
                    scanner.close();
                    System.exit(0);
                }
                default -> 
                    System.out.println("Valor invalido");
            }
        }
    }
    
    //Método para display da grade
    public static void displayGrade(){
        grade[0][0] = "Horarios";
        grade[0][1] = "segunda";
        grade[0][2] = "terca";
        grade[0][3] = "quarta";
        grade[0][4] = "quinta";
        grade[0][5] = "sexta";
        grade[0][6] = "sabado";
        
        grade[1][0] = "7:30";
        grade[2][0] = "8:30";
        grade[3][0] = "9:30";
        grade[4][0] = "10:30";
        
        for(String[] linha : grade){
           System.out.println(" " + Arrays.toString(linha));
        }
    }
    
    //Método para adicionar um evento na grade
    public static void adicionarNaGrade(){
        Scanner scanner = new Scanner(System.in);
        String evento;
        Dias diaDaSemana;
        Horario horario;

        System.out.println("Em que dia da semana? (segunda, terca, quarta, quinta, sexta, sabado)");
        diaDaSemana = Dias.valueOf(scanner.nextLine());

        switch(diaDaSemana){
            case segunda -> {
                /*
                7:30 = primeiro
                8:30 = segundo
                9:30 = terceiro
                10:30 = quarto 
                */
                System.out.println("Qual horario? (primeiro[7:30], segundo[8:30], ...)");
                horario = Horario.valueOf(scanner.nextLine());

                switch(horario){
                    case primeiro ->{
                        if(grade[1][1] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[1][1] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case segundo ->{
                        if(grade[2][1] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[2][1] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case terceiro ->{
                        if(grade[3][1] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[3][1] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case quarto ->{
                        if(grade[4][1] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[4][1] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                }
            }
            case terca -> {
                System.out.println("Qual horario? (primeiro[7:30], segundo[8:30], ...)");
                horario = Horario.valueOf(scanner.nextLine());

                switch(horario){
                    case primeiro ->{
                        if(grade[1][2] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[1][2] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case segundo ->{
                        if(grade[2][2] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[2][2] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case terceiro ->{
                        if(grade[3][2] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[3][2] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case quarto ->{
                        if(grade[4][2] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[4][2] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                }
            }
            case quarta -> {
                System.out.println("Qual horario? (primeiro[7:30], segundo[8:30], ...)");
                horario = Horario.valueOf(scanner.nextLine());

                switch(horario){
                    case primeiro ->{
                        if(grade[1][3] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[1][3] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case segundo ->{
                        if(grade[2][3] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[2][3] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case terceiro ->{
                        if(grade[3][3] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[3][3] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case quarto ->{
                        if(grade[4][3] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[4][3] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                }
            }
            case quinta -> {
                System.out.println("Qual horario? (primeiro[7:30], segundo[8:30], ...)");
                horario = Horario.valueOf(scanner.nextLine());

                switch(horario){
                    case primeiro ->{
                        if(grade[1][4] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[1][4] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case segundo ->{
                        if(grade[2][4] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[2][4] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case terceiro ->{
                        if(grade[3][4] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[3][4] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case quarto ->{
                        if(grade[4][4] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[4][4] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                }
            }
            case sexta -> {
                System.out.println("Qual horario? (primeiro[7:30], segundo[8:30], ...)");
                horario = Horario.valueOf(scanner.nextLine());

                switch(horario){
                    case primeiro ->{
                        if(grade[1][5] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[1][5] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case segundo ->{
                        if(grade[2][5] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[2][5] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case terceiro ->{
                        if(grade[3][5] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[3][5] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case quarto ->{
                        if(grade[4][5] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[4][5] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                }
            }
            case sabado -> {
                System.out.println("Qual horario? (primeiro[7:30], segundo[8:30], ...)");
                horario = Horario.valueOf(scanner.nextLine());

                switch(horario){
                    case primeiro ->{
                        if(grade[1][6] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[1][6] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case segundo ->{
                        if(grade[2][6] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[2][6] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case terceiro ->{
                        if(grade[3][6] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[3][6] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                    case quarto ->{
                        if(grade[4][6] == null){
                            System.out.println("Qual o evento?");
                            evento = scanner.nextLine();
                            grade[4][6] = evento;
                        }else{
                            System.out.println("Esse horario ja possui um compromisso\n");
                        }
                        displayGrade();
                    }
                }
            }
        } //fim do switch geral
    } //fim do metodo adicionar
} 
